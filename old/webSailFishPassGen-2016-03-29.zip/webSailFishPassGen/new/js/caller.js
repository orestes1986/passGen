function call(usCred, provCred, timesCred, lengCred, notWantCred) {
  var out = func(usCred, provCred, timesCred, lengCred, notWantCred);
  
    document.getElementById("outText").value = out;
}